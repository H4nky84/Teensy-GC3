#ifndef _ILI9341_t3_font_CourierNewItalic_
#define _ILI9341_t3_font_CourierNewItalic_

#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t CourierNew_8_Italic;
extern const ILI9341_t3_font_t CourierNew_9_Italic;
extern const ILI9341_t3_font_t CourierNew_10_Italic;
extern const ILI9341_t3_font_t CourierNew_11_Italic;
extern const ILI9341_t3_font_t CourierNew_12_Italic;
extern const ILI9341_t3_font_t CourierNew_13_Italic;
extern const ILI9341_t3_font_t CourierNew_14_Italic;
extern const ILI9341_t3_font_t CourierNew_16_Italic;
extern const ILI9341_t3_font_t CourierNew_18_Italic;
extern const ILI9341_t3_font_t CourierNew_20_Italic;
extern const ILI9341_t3_font_t CourierNew_24_Italic;
extern const ILI9341_t3_font_t CourierNew_28_Italic;
extern const ILI9341_t3_font_t CourierNew_32_Italic;
extern const ILI9341_t3_font_t CourierNew_40_Italic;
extern const ILI9341_t3_font_t CourierNew_48_Italic;
extern const ILI9341_t3_font_t CourierNew_60_Italic;
extern const ILI9341_t3_font_t CourierNew_72_Italic;
extern const ILI9341_t3_font_t CourierNew_96_Italic;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
