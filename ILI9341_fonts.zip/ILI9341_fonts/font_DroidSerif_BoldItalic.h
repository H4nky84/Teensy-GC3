#ifndef _ILI9341_t3_font_DroidSerif_BoldItalic_
#define _ILI9341_t3_font_DroidSerif_BoldItalic_

#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t DroidSerif_8_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_9_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_10_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_11_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_12_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_13_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_14_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_16_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_18_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_20_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_24_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_28_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_32_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_40_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_48_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_60_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_72_Bold_Italic;
extern const ILI9341_t3_font_t DroidSerif_96_Bold_Italic;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
