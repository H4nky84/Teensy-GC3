#ifndef _ILI9341_t3_font_Impact_
#define _ILI9341_t3_font_Impact_

#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Impact_8;
extern const ILI9341_t3_font_t Impact_9;
extern const ILI9341_t3_font_t Impact_10;
extern const ILI9341_t3_font_t Impact_11;
extern const ILI9341_t3_font_t Impact_12;
extern const ILI9341_t3_font_t Impact_13;
extern const ILI9341_t3_font_t Impact_14;
extern const ILI9341_t3_font_t Impact_16;
extern const ILI9341_t3_font_t Impact_18;
extern const ILI9341_t3_font_t Impact_20;
extern const ILI9341_t3_font_t Impact_24;
extern const ILI9341_t3_font_t Impact_28;
extern const ILI9341_t3_font_t Impact_32;
extern const ILI9341_t3_font_t Impact_40;
extern const ILI9341_t3_font_t Impact_48;
extern const ILI9341_t3_font_t Impact_60;
extern const ILI9341_t3_font_t Impact_72;
extern const ILI9341_t3_font_t Impact_96;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
