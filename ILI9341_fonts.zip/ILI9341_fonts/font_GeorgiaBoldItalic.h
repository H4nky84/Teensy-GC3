#ifndef _ILI9341_t3_font_GeorgiaBoldItalic_
#define _ILI9341_t3_font_GeorgiaBoldItalic_

#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Georgia_8_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_9_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_10_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_11_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_12_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_13_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_14_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_16_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_18_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_20_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_24_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_28_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_32_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_40_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_48_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_60_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_72_Bold_Italic;
extern const ILI9341_t3_font_t Georgia_96_Bold_Italic;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
