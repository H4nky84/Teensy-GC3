#ifndef _ILI9341_t3_font_ArialItalic_
#define _ILI9341_t3_font_ArialItalic_

#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Arial_8_Italic;
extern const ILI9341_t3_font_t Arial_9_Italic;
extern const ILI9341_t3_font_t Arial_10_Italic;
extern const ILI9341_t3_font_t Arial_11_Italic;
extern const ILI9341_t3_font_t Arial_12_Italic;
extern const ILI9341_t3_font_t Arial_13_Italic;
extern const ILI9341_t3_font_t Arial_14_Italic;
extern const ILI9341_t3_font_t Arial_16_Italic;
extern const ILI9341_t3_font_t Arial_18_Italic;
extern const ILI9341_t3_font_t Arial_20_Italic;
extern const ILI9341_t3_font_t Arial_24_Italic;
extern const ILI9341_t3_font_t Arial_28_Italic;
extern const ILI9341_t3_font_t Arial_32_Italic;
extern const ILI9341_t3_font_t Arial_40_Italic;
extern const ILI9341_t3_font_t Arial_48_Italic;
extern const ILI9341_t3_font_t Arial_60_Italic;
extern const ILI9341_t3_font_t Arial_72_Italic;
extern const ILI9341_t3_font_t Arial_96_Italic;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
