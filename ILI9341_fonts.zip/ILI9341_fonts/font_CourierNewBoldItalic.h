#ifndef _ILI9341_t3_font_CourierNewBoldItalic_
#define _ILI9341_t3_font_CourierNewBoldItalic_

#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t CourierNew_8_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_9_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_10_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_11_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_12_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_13_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_14_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_16_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_18_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_20_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_24_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_28_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_32_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_40_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_48_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_60_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_72_Bold_Italic;
extern const ILI9341_t3_font_t CourierNew_96_Bold_Italic;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
