#ifndef _ILI9341_t3_font_Logisoso_
#define _ILI9341_t3_font_Logisoso_

#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Logisoso_8;
extern const ILI9341_t3_font_t Logisoso_9;
extern const ILI9341_t3_font_t Logisoso_10;
extern const ILI9341_t3_font_t Logisoso_11;
extern const ILI9341_t3_font_t Logisoso_12;
extern const ILI9341_t3_font_t Logisoso_13;
extern const ILI9341_t3_font_t Logisoso_14;
extern const ILI9341_t3_font_t Logisoso_16;
extern const ILI9341_t3_font_t Logisoso_18;
extern const ILI9341_t3_font_t Logisoso_20;
extern const ILI9341_t3_font_t Logisoso_24;
extern const ILI9341_t3_font_t Logisoso_28;
extern const ILI9341_t3_font_t Logisoso_32;
extern const ILI9341_t3_font_t Logisoso_40;
extern const ILI9341_t3_font_t Logisoso_48;
extern const ILI9341_t3_font_t Logisoso_60;
extern const ILI9341_t3_font_t Logisoso_72;
extern const ILI9341_t3_font_t Logisoso_96;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
