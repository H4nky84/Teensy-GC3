#ifndef _ILI9341_t3_font_GeorgiaItalic_
#define _ILI9341_t3_font_GeorgiaItalic_

#include "ILI9341_t3.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const ILI9341_t3_font_t Georgia_8_Italic;
extern const ILI9341_t3_font_t Georgia_9_Italic;
extern const ILI9341_t3_font_t Georgia_10_Italic;
extern const ILI9341_t3_font_t Georgia_11_Italic;
extern const ILI9341_t3_font_t Georgia_12_Italic;
extern const ILI9341_t3_font_t Georgia_13_Italic;
extern const ILI9341_t3_font_t Georgia_14_Italic;
extern const ILI9341_t3_font_t Georgia_16_Italic;
extern const ILI9341_t3_font_t Georgia_18_Italic;
extern const ILI9341_t3_font_t Georgia_20_Italic;
extern const ILI9341_t3_font_t Georgia_24_Italic;
extern const ILI9341_t3_font_t Georgia_28_Italic;
extern const ILI9341_t3_font_t Georgia_32_Italic;
extern const ILI9341_t3_font_t Georgia_40_Italic;
extern const ILI9341_t3_font_t Georgia_48_Italic;
extern const ILI9341_t3_font_t Georgia_60_Italic;
extern const ILI9341_t3_font_t Georgia_72_Italic;
extern const ILI9341_t3_font_t Georgia_96_Italic;

#ifdef __cplusplus
} // extern "C"
#endif

#endif
